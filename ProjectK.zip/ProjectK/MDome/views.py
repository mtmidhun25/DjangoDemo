from django.shortcuts import render,redirect
from .models import*
from django.contrib import messages
from django.contrib.auth import authenticate

# Create your views here.


def index(request):
    return render(request,'index.html')
def register(request):
    return render(request,'register.html')
def login(request):
    return render(request,'login.html')


def register1(request):
    objj=Login()
    objj.username=request.POST.get("username")
    objj.password=request.POST.get("password")
    objj.usertype="user"
    objj.status="Approved"
    objj.save()
    obj=UInfo()
    obj.name=request.POST.get("name")
    obj.address=request.POST.get("address")
    obj.ph_no=request.POST.get("phone")
    obj.email=request.POST.get("email")
    obj.login=objj
    obj.save()
    messages.add_message(request, messages.INFO, 'Registered Successfully.')
    return redirect('register')


    # return render(request,'success.html',{'name':name,'address':address})

def login_action(request):
    usr=request.POST.get("username")
    pwd=request.POST.get("password")
    obj=authenticate(username=usr,password=pwd)
    if obj is not None:
        if obj.is_superuser==1:
            request.session['aname'] = usr
            request.session['slogid'] = obj.id
            return redirect('admin_home')
        else:
            messages.add_message(request,messages.INFO,'Invalid User.')
            return redirect('login')
    else:
        messages.add_message(request,messages.INFO,'Invalid User.')
        return redirect('login')

def admin_home(request):
    if 'aname' in request.session:
        return render(request, 'Master/index.html')
    else:
        return redirect('login')
    
def userlist(request):
    if 'aname' in request.session:
        data=UInfo.objects.all()
        return render(request, 'Master/userlist.html',{'udata':data})
    else:
        return redirect('login')
def addbook(request):
    if 'aname' in request.session:
        return render(request, 'Master/addbook.html')
    else:
        return redirect('login')
def booklist(request):
    if 'aname' in request.session:
        return render(request, 'Master/booklist.html')
    else:
        return redirect('login')
    
# def user_home
