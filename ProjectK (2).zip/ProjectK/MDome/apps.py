from django.apps import AppConfig


class MdomeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'MDome'
