from django.shortcuts import render,redirect
from .models import*
from django.contrib import messages
from django.contrib.auth import authenticate
from django.contrib.auth import logout
from django.core.files.storage import FileSystemStorage
from django.conf import settings
import os

# Create your views here.


def index(request):
    return render(request,'index.html')
def register(request):
    return render(request,'register.html')
def login(request):
    return render(request,'login.html')


def register1(request):
    username=request.POST.get("username")
    data = {
        'username_exists': Login.objects.filter(username=username).exists(),'error':"Username already exists"
    }
    if(data["username_exists"]==False):
        objj=Login()
        objj.username=request.POST.get("username")
        objj.password=request.POST.get("password")
        objj.usertype="user"
        objj.status="Approved"
        objj.save()
        obj=UInfo()
        obj.name=request.POST.get("name")
        obj.address=request.POST.get("address")
        obj.ph_no=request.POST.get("phone")
        obj.email=request.POST.get("email")
        obj.login=objj
        obj.save()
        messages.add_message(request, messages.INFO, 'Registered Successfully.')
        return redirect('register')
    else:
        messages.add_message(request,messages.INFO,'Username already Exists! Sorry Registration failed')
        return redirect('register')


    # return render(request,'success.html',{'name':name,'address':address})

def login_action(request):
    usr = request.POST.get("username")
    pwd = request.POST.get("password")

    obj = authenticate(username=usr, password=pwd)
    if obj is not None:
        if obj.is_superuser == 1:
            request.session['aname'] = usr
            request.session['slogid'] = obj.id
            return redirect('admin_home')
        else:
            messages.add_message(request, messages.INFO, 'Invalid User.')
            return redirect('login')
    else:
        obj1 = Login.objects.get(username=usr, password=pwd)
        if obj1.usertype == "user":
            if obj1.status == "Approved":
                request.session['uname'] = usr
                request.session['slogid'] = obj1.login_id
                return redirect('user_home')
            elif obj1.status == "Not Approved":
                messages.add_message(request, messages.INFO, 'Waiting For Approval.')
                return redirect('login')
            else:
                messages.add_message(request, messages.INFO, 'Invalid User.')
                return redirect('login')
        else:
            messages.add_message(request, messages.INFO, 'Invalid User.')
            return redirect('login')

def admin_home(request):
    if 'aname' in request.session:
        return render(request, 'Master/index.html')
    else:
        return redirect('login')

def user_home(request):
    if 'uname' in request.session:
        return render(request, 'User/uindex.html')
    else:
        return redirect('login')
    
def userlist(request):
    if 'aname' in request.session:
        data=UInfo.objects.all().select_related('login')
        return render(request, 'Master/userlist.html',{'udata':data})
    else:
        return redirect('login')
    
def addbook(request):
    if 'aname' in request.session:
        if request.method == 'POST':
            obj = Book()
            obj.bookname = request.POST.get("bookname")
            obj.author = request.POST.get("author")
            obj.description = request.POST.get("description")
            obj.price = request.POST.get("price")
            image=request.FILES['image']
            split_tup=os.path.splitext(image.name)
            file_extension=split_tup[1]
            # folder path
            dir_path = settings.MEDIA_ROOT
            count = 0
            for path in os.listdir(dir_path):
                if os.path.isfile(os.path.join(dir_path,path)):
                    count += 1
            filecount=count+1
            filename=str(filecount)+file_extension
            fob=FileSystemStorage()
            file=fob.save(filename,image)
            url1=fob.url(file)
            obj.image=url1
            obj.save()
            messages.add_message(request, messages.INFO, 'Book added succesfully')
            return render(request, 'Master/addbook.html')
        return render(request, 'Master/addbook.html')
    else:
        return redirect('login')

    


def booklist(request):
    if 'aname' in request.session:  
        data=Book.objects.all()
        return render(request, 'Master/booklist.html',{'books':data})
    else:
      return redirect('login')
        
        

def logout_view(request):
    logout(request)  
    request.session.flush() 
    return redirect('login') 

def delete_book(request,id):
    obj=Book.objects.get(book_id=id)
    obj.delete()
    messages.add_message(request, messages.INFO, 'Book deleted succesfully')
    return redirect('booklist')
    # obj=Book.objects.filter(author='name')

def edit_book(request,id):
    obj=Book.objects.get(book_id=id)
    # obj.edit()
    # messages.add_message(request, messages.INFO, 'Book edited succesfully')
    return render(request,'Master/edit_book.html',{'data':obj})

def update_book(request):
    id=request.POST.get('book_id')
    obj = Book.objects.get(book_id=id)
    obj.bookname = request.POST.get("bookname")
    obj.author = request.POST.get("author")
    obj.description = request.POST.get("description")
    obj.price = request.POST.get("price")
    obj.save()
    messages.add_message(request, messages.INFO, 'Book Details updated succesfully')
    return redirect('booklist')

def profile(request):
    
    login_id=request.session['slogid']
    data=UInfo.objects.get(login_id=login_id)
    return render(request,'User/profile.html',{'data':data})

def books(request):
    if 'uname' in request.session:  
        data=Book.objects.all()
        return render(request, 'User/books.html',{'books':data})
    else:
        return redirect('login')
    
def more(request,id):
    if 'uname' in request.session:  
        obj=Book.objects.get(book_id=id)
        return render(request, 'User/more.html',{'data':obj})
    else:
        return redirect('login')


def edit_profile(request):
    
    login_id=request.session['slogid']
    user=UInfo.objects.get(login_id=login_id)
    return render(request,'User/edit_profile.html',{'data':user})

def edit_info(request):
    login_id=request.session['slogid']
    obj=UInfo.objects.get(login_id=login_id)
    obj.name=request.POST.get("name")
    obj.address=request.POST.get("address")
    obj.ph_no=request.POST.get("phone")
    obj.email=request.POST.get("email")
    obj.save()
    messages.add_message(request, messages.INFO, 'Profile updated Successfully.')
    return redirect('profile')



# def user_home