"""
URL configuration for ProjectK project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.urls import path
from MDome import views
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('', views.index,name="index"),
    path('login/',views.login,name="login"),
    path('register/',views.register,name="register"),
    path('register1/',views.register1,name="register1"),
    path('login_action/',views.login_action,name="login_action"),
    path('logout_view/',views.logout_view,name="logout_view"),
    path('admin_home/',views.admin_home,name="admin_home"),
    path('user_home/',views.user_home,name="user_home"),
    path('userlist/',views.userlist,name="userlist"),
    path('addbook/',views.addbook,name="addbook"),
    path('booklist/',views.booklist,name="booklist"),
    path('delete_book/<int:id>',views.delete_book,name="delete_book"),
    path('edit_book/<int:id>',views.edit_book,name="edit_book"),
    path('update_book/',views.update_book,name="update_book"),
    path('profile/',views.profile,name="profile"),
    path('edit_profile/',views.edit_profile,name="edit_profile"),
    path('edit_info/',views.edit_info,name="edit_info"),
    path('books/',views.books,name="books"),
    path('more/<int:id>',views.more,name="more")
]
if settings.DEBUG:
    urlpatterns += static ( settings.MEDIA_URL , document_root=settings.MEDIA_ROOT)
