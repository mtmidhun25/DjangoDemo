from django.db import models
from django.contrib.auth.models import AbstractUser

# User Roles
USER_ROLES = [
    ('patient', 'Patient'),
    ('doctor', 'Doctor'),
    ('ngo', 'NGO Worker'),
    ('admin', 'Admin'),
]

# Custom User model
class CustomUser(AbstractUser):
    role = models.CharField(max_length=20, choices=USER_ROLES, default='patient')
    phone = models.CharField(max_length=15, blank=True)

# Patient Profile (Linked to User)
class PatientProfile(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    age = models.IntegerField(null=True, blank=True)
    gender = models.CharField(max_length=10, blank=True)
    address = models.TextField(blank=True)
    medical_history = models.TextField(blank=True)

# Healthcare or Welfare Services
class Service(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    location = models.CharField(max_length=100)
    scheduled_date = models.DateTimeField()
    provider = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, related_name='services')
    type = models.CharField(max_length=50, choices=[
        ('camp', 'Medical Camp'),
        ('vaccine', 'Vaccination'),
        ('mental', 'Mental Health'),
        ('welfare', 'Welfare Scheme'),
    ])
    is_active = models.BooleanField(default=True)

# Appointment Booking
class Appointment(models.Model):
    patient = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='appointments')
    doctor = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='doctor_appointments')
    service = models.ForeignKey(Service, on_delete=models.SET_NULL, null=True)
    date = models.DateField()
    time = models.TimeField()
    status = models.CharField(max_length=20, default='pending')

