from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib import messages

def homepage(request):
    return render(request, 'homepage.html')

def login_view(request):
    return render(request, 'login.html')

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Account created successfully! You can now log in.')
            return redirect('login')  # use the name you gave in urls.py
    else:
        form = UserCreationForm()
    
    return render(request, 'register.html', {'form': form})
